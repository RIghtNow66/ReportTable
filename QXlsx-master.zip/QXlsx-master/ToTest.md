# To Test

- The following tests should be performed. 
	- Microsoft Excel, Google Spreadsheet, LibreOffice Calc Spreadsheet

- Unicode test (filename :cloud:, filepath :cloud:, data value :sunny:)
